# ecommerce-website
A simple e-commerce website for a small business which sells apparels.
